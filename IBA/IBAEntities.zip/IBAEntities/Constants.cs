﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBAEntities
{
    public class Constants
    {
        public enum StaffType { User, Admin};

        public const int DEFAULTVALUE = -1;

        public const string USERSESSIONVAR = "UserSessionVar";
        public const string StartYear = "StartYear";
    }
}
